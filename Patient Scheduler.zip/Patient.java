import java.util.GregorianCalendar;

public class Patient extends Person{
  
    public Patient(String firstName, String lastName, char gender, GregorianCalendar birthday, String address) {
       
        super(firstName, lastName, gender, birthday, address);
    }

}