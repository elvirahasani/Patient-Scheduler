import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Database {
   private Appointment[] appointments = new Appointment[100];
   private int lastAdded = 0;

   
    public Appointment saveAppointment(GregorianCalendar appointmentDate, Patient patient) {
           if (lastAdded % 100 == 0) {
            expandAppointmentsArray();
        }

        appointments[lastAdded] = new Appointment(appointmentDate, patient);
        lastAdded += 1;
        System.out.println("Appointment added successfully!");
        
        return appointments[lastAdded - 1];

    }

    
    public void cancelAppointment(Appointment appointment) {
        for (int i = 0; i < lastAdded; i++) {
            
            if (appointment == appointments[i]) {
                appointments[i] = null;
                System.out.println("Appointment cancelled successfully!");
            }
        }
    }

    
    public void listAppointments() {
        for (int i = 0; i < lastAdded; i++) {
            if (appointments[i] != null) {
                System.out.println(appointments[i]);
                System.out.println("--------------------------------------");
            }
        }
    }

    public void listAppointmentsByPatient(Patient patient) {
        for (int i = 0; i < lastAdded; i++) {
            if (appointments[i] != null && appointments[i].getPatient() == patient) {
                System.out.println(appointments[i]);
                System.out.println("--------------------------------------");
            }
        }
    }

    public void listAppointmentsByDay(GregorianCalendar date) {
        for (int i = 0; i < lastAdded; i++) {
            if (appointments[i] != null && isTheSameDay(date.getTime(), appointments[i].getAppointmentDate().getTime())) {
                System.out.println(appointments[i]);
                System.out.println("--------------------------------------");
            }
        }
    }

    
    public void expandAppointmentsArray() {
               Appointment[] temp = new Appointment[lastAdded + 100];
               for (int i = 0; i < lastAdded; i++) {
            temp[i] = this.appointments[i];
        }
               this.appointments = temp;
    }

    private boolean isTheSameDay(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date1);
        cal2.setTime(date2);
        boolean sameDay = cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR) &&
                cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);
        return sameDay;
    }
}
