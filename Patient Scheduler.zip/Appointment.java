import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public class Appointment {
    private GregorianCalendar appointmentDate;
    private Patient patient;

    
    public Appointment(GregorianCalendar appointmentDate1, Patient patient1) {
        this.appointmentDate = appointmentDate1;
        this.patient = patient1;
    }

    public GregorianCalendar getAppointmentDate() {
        return appointmentDate;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setAppointmentDate(GregorianCalendar appointmentDate2) {
        this.appointmentDate = appointmentDate2;

    }

    public void setPatient(Patient patient2) {
        this.patient = patient2;
    }

   
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
  return ("Date: " + dateFormat.format(appointmentDate.getTime()) + "\n" + "Patient: " + patient.getFirstName() + " " + patient.getLastName());
    }
}
