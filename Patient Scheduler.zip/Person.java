import java.util.GregorianCalendar;

public class Person {
    private String firstName;
    private String lastName;
    private char gender;
    private GregorianCalendar birthday;
    private String address;

 
    public Person(String firstName, String lastName, char gender, GregorianCalendar birthday, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.birthday = birthday;
        this.address = address;
    }

       public void setFirstName(String firstName1) {
        this.firstName = firstName1;
    }

        public void setLastName(String lastName1) {
        this.lastName = lastName1;
    }

     public void setGender(char gender1) {
        this.gender = gender1;
    }

  
    public void setBirthday(GregorianCalendar birthday1) {
        this.birthday = birthday1;
    }

    public void setAddress(String address1) {
        this.address = address1;
    }

    public String getFirstName() {
        return this.firstName;
    }

   
       public String getLastName() {
        return this.lastName;
    }

    
    public char getGender() {
        return this.gender;
    }

    
    public GregorianCalendar getBirthday() {
        return this.birthday;
    }

   
    public String getAddress() {
        return this.address;
    }
}
