import java.util.GregorianCalendar;

public class Main {
    public static void main(String[] args) {
     Database spitaliRajonal = new Database();

    Patient firstPatient = new Patient("David", "Mitchell", 'M', new GregorianCalendar(1980, 1, 3),
                "Street Mother Teresa");

    Patient secondPatient = new Patient("Jessica", "Wesley", 'F', new GregorianCalendar(1980, 1, 3),
                "Street Luan Haradinaj");

    GregorianCalendar appointmentDate1 = new GregorianCalendar(2020, 6, 2, 2, 10);

                
    Appointment firstAppointment = spitaliRajonal.saveAppointment(appointmentDate1, firstPatient);

        GregorianCalendar appointmentDate2 = new GregorianCalendar(2019, 6, 1, 11, 10);
        
        Appointment secondAppointment = spitaliRajonal.saveAppointment(appointmentDate2, secondPatient);

        GregorianCalendar appointmentDate3 = new GregorianCalendar(2020, 6, 2, 10, 12);
        Appointment thirdAppointment = spitaliRajonal.saveAppointment(appointmentDate3, firstPatient);

       spitaliRajonal.listAppointments();

      
        spitaliRajonal.cancelAppointment(firstAppointment);
        System.out.println("----------After cancelling---------");
        System.out.println();

        
        spitaliRajonal.listAppointments();


        System.out.println("------Get all appoiments for a patient (in our case for patient one) -------------");
        spitaliRajonal.listAppointmentsByPatient(firstPatient);


        System.out.println("------Get all appoiments by a day (2 July 2020) -------------");
        spitaliRajonal.listAppointmentsByDay(new GregorianCalendar(2020, 6, 2));
    }
}
